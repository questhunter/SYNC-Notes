$result   = mysqli_query($mysqli, "UPDATE users SET notes=$notes WHERE email='sathya@gmail.com");
