<?php

?>

<html>

<head>

<body>

    
    <br /> <br />
    <div>
        <a href="login.php"> Login</a> | <a href="register.php"> Register</a>
    </div>

</body>

</html>